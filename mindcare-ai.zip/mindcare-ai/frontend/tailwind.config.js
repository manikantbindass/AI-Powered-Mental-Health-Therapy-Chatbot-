export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        sage: { 50: "#f4f7f4", 100: "#e3ebe3", 500: "#5c8562", 600: "#476b4c", 700: "#39563d" },
        warm: { 50: "#faf9f5", 100: "#f2efe9" },
        lavender: { 500: "#7e6fa6" }
      }
    }
  },
  plugins: []
};
